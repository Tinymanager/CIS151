package Unit_4.PedrickUnit4a;

public class InfiniteLoop {
    public static void main(String[] args) {
   
    // The for loop will run infinite times.
    for(int i = 0; i <= 4; i++){
        System.out.println("Hello");
    }
     
    // To terminate this program press ctrl + c in the console.
  }
}
