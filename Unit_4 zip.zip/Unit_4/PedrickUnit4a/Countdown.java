package Unit_4.PedrickUnit4a;

public class Countdown {

    public static void main(String[] args) {
        
        System.out.println("Countdown to Launch: ");

        for(int i = 0; i <= 5; i++) {
            System.out.print(i +" "); 
        }

        System.out.println("Blast Off!");

        
    System.out.println("Let's Count Even Numbers: ");

    for(int i = 0; i <= 20; i = i + 2) {
        System.out.print(i +" "); 
    }

    System.out.println("Done!");
}
}
