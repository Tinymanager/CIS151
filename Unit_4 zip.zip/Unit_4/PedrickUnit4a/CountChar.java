package Unit_4.PedrickUnit4a;

public class CountChar {

    public static void main(String[] args) {

        String str = "www.oracle.com";

        int max = str.length();
        int count = 0;
        for (int i = 0; i < max; i++){
            
            if (str.charAt(i) != 'w') {
                continue;
            } 
            count++;
        }
        
        
        System.out.println("Counting w : " + count );
        //is i < max, if string character isnt = w continue and increase i
        // if (str.charAt(i) != 'w')
        //                continue;

    }
}
