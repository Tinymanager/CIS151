public class Demo_Three {
    public static void main(String[] args) {
      // two integer variables with values
      // and a variable "sum" to store the result
      int num1 = 5, num2 = 15,sum;
  
      //calculating the sum of num1 and num2 and
      //storing the result in the variable sum
      sum = num1+num2;
  
      //printing the result
      System.out.println("Sum of "+num1+" and "+num2+" is: "+sum);
    }
  }